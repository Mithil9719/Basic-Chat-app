package com.example.projectapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Chat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
    }

    public void sendMessege(View v) {
        String messege = ((EditText)(findViewById(R.id.editText_Messege))).getText().toString();
        Uri destination = Uri.parse("smsto:5556");
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO , destination);
        smsIntent.putExtra("sms_body" , messege);
        startActivity(smsIntent);
    }
}