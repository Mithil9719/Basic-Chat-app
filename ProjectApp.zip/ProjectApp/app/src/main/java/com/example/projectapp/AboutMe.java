package com.example.projectapp;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.NumberPicker;

import androidx.appcompat.app.AppCompatActivity;

public class AboutMe extends AppCompatActivity {

    NumberPicker possibilities;
    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_me);

        possibilities = findViewById(R.id.numberPicker);
        webView = findViewById(R.id.webView);
        String[] possibilitiesString = {
                "Instagram",
                "Twitter",
                "LinkedIN",
                "GitHub",
        };
        possibilities.setDisplayedValues(possibilitiesString);
        possibilities.setMinValue(0);
        possibilities.setMaxValue(possibilitiesString.length-1);
    }

    public void navigate(View y){
        int choice = possibilities.getValue();
        if(choice == 0)
            webView.loadUrl("https://www.instagram.com/invites/contact/?i=l5qo2kxixcqh&utm_content=h4xn4sl");
        else if(choice == 1)
            webView.loadUrl("https://twitter.com/Meethil3?s=08");
        else if(choice == 2)
            webView.loadUrl("https://www.linkedin.com/in/mithil-parmar-04466819a");
        else if(choice == 3)
            webView.loadUrl("https://github.com/Mithil9719");
    }
}


